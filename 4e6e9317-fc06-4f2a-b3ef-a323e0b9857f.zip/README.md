# ياسين افلامي - Tunisian Ramadan Streaming Platform

A professional video streaming platform for Tunisian Ramadan series with a modern Arabic RTL interface and full admin dashboard.

## 🌙 Features

### User Side
- **Modern Netflix-style Interface**: Dark theme with gold/red accents
- **RTL Arabic Layout**: Optimized for Arabic content
- **Hero Slider**: Featured series showcase
- **Categories**: Filter by genre (Drama, Comedy, Historical, etc.)
- **Search**: Live search functionality
- **Video Player**: Embedded player with episode navigation
- **Responsive Design**: Mobile-first approach

### Admin Dashboard
- **Authentication**: Secure admin login system
- **Series Management**: Add, edit, delete series
- **Episode Management**: Manage episodes with video URLs
- **Ads Management**: Dynamic ad placement control
  - Header Ad
  - Sidebar Ad
  - Between Episodes Ad
  - Before/After Episode Ads
  - Footer Ad
- **Full Control**: Enable/disable ads, add custom ad codes

## 🚀 Deployment on Vercel

### Prerequisites
- Vercel account (free)
- Git repository
- Node.js installed (optional, for development)

### Quick Deploy

1. **Install Vercel CLI** (optional)
   ```bash
   npm install -g vercel
   ```

2. **Deploy with Vercel CLI**
   ```bash
   vercel
   ```

3. **Or Deploy via Vercel Dashboard**
   - Go to [vercel.com](https://vercel.com)
   - Click "Add New Project"
   - Import your Git repository
   - Vercel will detect the static site automatically
   - Click "Deploy"

### Manual Deploy Steps

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd yasin-aflemy
   ```

2. **Push to GitHub/GitLab**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

3. **Import to Vercel**
   - Login to Vercel
   - Click "Add New Project"
   - Select your repository
   - Configure settings (default is fine)
   - Click "Deploy"

## 📁 Project Structure

```
yasin-aflemy/
├── index.html              # Home page
├── series.html            # Series details page
├── player.html            # Video player page
├── search.html            # Search page
├── categories.html        # Categories page
├── admin.html             # Admin login page
├── dashboard.html         # Admin dashboard
├── css/
│   └── style.css          # Main stylesheet
├── js/
│   ├── main.js            # Core functionality
│   ├── slider.js          # Hero slider
│   ├── series.js          # Series page logic
│   ├── player.js          # Video player logic
│   ├── search.js          # Search functionality
│   ├── categories.js      # Categories filtering
│   └── admin.js           # Admin dashboard logic
├── images/                # Image assets
├── vercel.json            # Vercel configuration
└── README.md              # This file
```

## 🔧 Configuration

### Firebase Integration (Optional)

To enable real database and authentication:

1. **Create Firebase Project**
   - Go to [console.firebase.google.com](https://console.firebase.google.com)
   - Create new project
   - Enable Realtime Database
   - Enable Authentication

2. **Update Firebase Config**
   - Open `js/main.js`
   - Replace the `firebaseConfig` object with your Firebase credentials:
   ```javascript
   const firebaseConfig = {
       apiKey: "YOUR_API_KEY",
       authDomain: "YOUR_PROJECT.firebaseapp.com",
       databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
       projectId: "YOUR_PROJECT",
       storageBucket: "YOUR_PROJECT.appspot.com",
       messagingSenderId: "YOUR_SENDER_ID",
       appId: "YOUR_APP_ID"
   };
   ```

3. **Uncomment Firebase Code**
   - Uncomment Firebase initialization in `js/main.js`

### Default Admin Credentials

- **Username**: `admin`
- **Password**: `yasin123`

⚠️ **Important**: Change these credentials in production!

## 🎨 Customization

### Changing Colors

Edit `css/style.css` variables:
```css
:root {
    --primary-gold: #D4AF37;
    --primary-red: #8B0000;
    --dark-bg: #0a0a0a;
    /* ... */
}
```

### Adding Sample Data

The platform comes with sample series and episodes. To add your own:

1. **Via Admin Dashboard** (Recommended)
   - Login to admin panel
   - Go to "إدارة المسلسلات"
   - Add new series
   - Go to "إدارة الحلقات"
   - Add episodes

2. **Via JavaScript**
   - Edit sample data arrays in `js/main.js`
   - Or use Firebase for real-time data

## 📱 Mobile Responsiveness

The platform is fully responsive and works on:
- Desktop (1920px+)
- Laptop (1024px - 1919px)
- Tablet (768px - 1023px)
- Mobile (320px - 767px)

## 🎯 Key Features

### User Experience
- Smooth animations and transitions
- Fast loading times
- Intuitive navigation
- Beautiful Arabic typography
- Professional streaming feel

### Admin Features
- Easy-to-use dashboard
- Real-time updates
- Secure authentication
- Complete content control
- Ad management system

### Monetization
- Support for Google AdSense
- Custom banner ads
- Multiple ad placements
- Enable/disable control

## 🔒 Security Notes

- **In Production**: Use Firebase Authentication
- **Change Admin Credentials**: Update `js/admin.js`
- **HTTPS**: Vercel provides free SSL certificates
- **Firebase Security Rules**: Set proper database rules

## 📝 Development

### Local Testing

1. **Using Python** (Recommended)
   ```bash
   python3 -m http.server 8000
   ```

2. **Using Node.js**
   ```bash
   npx serve
   ```

3. **Using VS Code Live Server**
   - Install Live Server extension
   - Right-click on `index.html`
   - Select "Open with Live Server"

### Adding New Features

The codebase is modular and easy to extend:
- CSS: Add new styles to `css/style.css`
- JavaScript: Add new functions to appropriate JS files
- Pages: Create new HTML pages following the existing pattern

## 🐛 Troubleshooting

### Images Not Loading
- Check image URLs are valid
- Use absolute URLs or host images on a CDN

### Admin Panel Not Working
- Clear browser localStorage
- Check browser console for errors
- Verify admin credentials

### Videos Not Playing
- Ensure video URLs are accessible
- Check video format (MP4 recommended)
- Verify CORS settings for external videos

## 📞 Support

For issues or questions:
- Check the code comments
- Review browser console errors
- Test in different browsers

## 📄 License

This project is open source and available for educational purposes.

## 🙏 Credits

- Design inspired by popular streaming platforms
- Icons: Font Awesome
- Images: Unsplash (for demo purposes)

---

**ياسين افلامي** - Your premier destination for Tunisian Ramadan series streaming!