# 🚀 Quick Start Guide - ياسين افلامي

## Setup in 5 Minutes

### 1. Local Testing

```bash
# Option 1: Python (Easiest)
python3 -m http.server 8000

# Option 2: Node.js
npx serve

# Option 3: PHP
php -S localhost:8000
```

Then open `http://localhost:8000` in your browser.

### 2. Admin Access

- Go to `http://localhost:8000/admin.html`
- **Username**: `admin`
- **Password**: `yasin123`

### 3. Deploy to Vercel

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel
```

Or use Vercel Dashboard:
1. Push code to GitHub
2. Import project in Vercel
3. Click Deploy

## First Steps After Setup

### Add Your First Series

1. Login to Admin Dashboard
2. Click "إضافة مسلسل جديد"
3. Fill in:
   - Title (e.g., "نزل البركة")
   - Description
   - Poster URL (use any image URL)
   - Category (دراما, كوميديا, etc.)
   - Year (2024)
   - Rating (8.5)

### Add Episodes

1. Go to "إدارة الحلقات"
2. Click "إضافة حلقة جديدة"
3. Fill in:
   - Select the series
   - Episode number (1, 2, 3...)
   - Episode title
   - Video URL (MP4 link)
   - Duration in minutes

### Add Ads (Optional)

1. Go to "إدارة الإعلانات"
2. Select ad placement (Header, Sidebar, etc.)
3. Toggle "تفعيل" to enable
4. Paste Google Ads code or HTML banner code
5. Click "حفظ الإعلان"

## Customization

### Change Site Title

Edit `index.html`:
```html
<a href="index.html" class="logo">
    <i class="fas fa-play-circle"></i>
    ياسين <span>افلامي</span>
</a>
```

### Change Colors

Edit `css/style.css`:
```css
:root {
    --primary-gold: #D4AF37;
    --primary-red: #8B0000;
}
```

### Change Admin Credentials

Edit `js/admin.js`:
```javascript
const ADMIN_USERNAME = 'your_username';
const ADMIN_PASSWORD = 'your_password';
```

## Video Sources

### Where to host videos?

1. **Your own server**: Upload MP4 files
2. **Cloud storage**: AWS S3, Google Cloud Storage
3. **Video hosting**: Vimeo, YouTube (embed URLs)
4. **CDN**: Cloudflare, BunnyCDN

### Video format

- Recommended: MP4 (H.264 codec)
- Resolution: 720p or 1080p
- Bitrate: 2000-5000 kbps

## Image Sources

### Where to get poster images?

1. **Unsplash**: https://unsplash.com (Free)
2. **Pexels**: https://pexels.com (Free)
3. **Pixabay**: https://pixabay.com (Free)
4. **Your own images**: Upload to cloud storage

### Recommended size

- Poster: 400x600px (2:3 ratio)
- Hero: 1920x1080px (16:9 ratio)

## Common Issues

### Videos not playing?
- Check video URL is accessible
- Ensure video format is MP4
- Check CORS settings

### Admin not working?
- Clear browser cache
- Check console for errors
- Verify credentials

### Images not loading?
- Use absolute URLs
- Check image URL is valid
- Test URL in browser

## Next Steps

1. ✅ Deploy to Vercel
2. ✅ Add your series and episodes
3. ✅ Customize design (colors, logo)
4. ✅ Set up Firebase (for real database)
5. ✅ Add Google Analytics
6. ✅ Set up custom domain

## Need Help?

Check `README.md` for detailed documentation.

---

**ياسين افلامي** - Start streaming in minutes! 🌙