// Main JavaScript for ياسين افلامي

// Firebase Configuration (Replace with your Firebase config)
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
    projectId: "YOUR_PROJECT",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase (uncomment when you have real config)
// firebase.initializeApp(firebaseConfig);
// const db = firebase.database();

// Sample data for demo purposes
let sampleSeries = [
    {
        id: '1',
        title: 'نزل البركة',
        description: 'مسلسل كوميدي تونسي ساخر يروي قصة عائلة تونسية في شهر رمضان المبارك. المسلسل يتناول قضايا اجتماعية بطريقة كوميدية خفيفة.',
        poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400',
        category: 'كوميديا',
        year: 2024,
        rating: 8.5,
        views: 150000
    },
    {
        id: '2',
        title: 'عفريت عملي',
        description: 'دراما اجتماعية تونسية تجسد واقع المجتمع التونسي في قصة مشوقة تدور حول الشباب وطموحاتهم.',
        poster: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400',
        category: 'دراما',
        year: 2024,
        rating: 9.0,
        views: 200000
    },
    {
        id: '3',
        title: 'ولد البلاد',
        description: 'مسلسل تاريخي يحكي قصة تونس عبر العصور في أجواء رمضانية مميزة مع شخصيات تاريخية بارزة.',
        poster: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400',
        category: 'تاريخي',
        year: 2024,
        rating: 8.8,
        views: 180000
    },
    {
        id: '4',
        title: 'قحطة عيون',
        description: 'مسلسل رومانسي تونسي يدور حول قصة حlove بين شابين في ظل الأجواء الرمضانية.',
        poster: 'https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=400',
        category: 'رومانسي',
        year: 2024,
        rating: 8.2,
        views: 120000
    },
    {
        id: '5',
        title: 'المقداد',
        description: 'مسلسل تاريخي ملحمي يحكي قصة الصحابي المقداد بن عمرو في عهد النبي محمد صلى الله عليه وسلم.',
        poster: 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400',
        category: 'تاريخي',
        year: 2023,
        rating: 9.2,
        views: 250000
    },
    {
        id: '6',
        title: 'أبي الطيب',
        description: 'دراما تاريخية تحكي قياة الشاعر العربي الكبير أبو الطيب المتنبي.',
        poster: 'https://images.unsplash.com/photo-1503095396549-807759245b35?w=400',
        category: 'دراما',
        year: 2023,
        rating: 8.9,
        views: 190000
    }
];

let sampleEpisodes = [
    {
        id: '1',
        seriesId: '1',
        episodeNumber: 1,
        title: 'الحلقة 1',
        videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4',
        duration: 45
    },
    {
        id: '2',
        seriesId: '1',
        episodeNumber: 2,
        title: 'الحلقة 2',
        videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4',
        duration: 43
    },
    {
        id: '3',
        seriesId: '2',
        episodeNumber: 1,
        title: 'الحلقة 1',
        videoUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4',
        duration: 48
    }
];

let sampleAds = {
    header: { enabled: false, code: '' },
    sidebar: { enabled: false, code: '' },
    'between-episodes': { enabled: false, code: '' },
    'before-episode': { enabled: false, code: '' },
    'after-episode': { enabled: false, code: '' },
    footer: { enabled: false, code: '' }
};

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initHeader();
    loadAds();
    loadHomePageContent();
});

// Header scroll effect
function initHeader() {
    const header = document.getElementById('header');
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
}

// Load ads from localStorage or use sample data
function loadAds() {
    const storedAds = localStorage.getItem('yasinAflemy_ads');
    if (storedAds) {
        window.ads = JSON.parse(storedAds);
    } else {
        window.ads = sampleAds;
    }
    displayAds();
}

// Display ads on page
function displayAds() {
    const adTypes = ['header', 'sidebar', 'between-episodes', 'before-episode', 'after-episode', 'footer'];
    
    adTypes.forEach(type => {
        const adElement = document.getElementById(`${type}-ad`);
        if (adElement && window.ads[type] && window.ads[type].enabled) {
            if (window.ads[type].code) {
                adElement.innerHTML = window.ads[type].code;
            }
        }
    });
}

// Load series data
function getSeries() {
    const storedSeries = localStorage.getItem('yasinAflemy_series');
    if (storedSeries) {
        return JSON.parse(storedSeries);
    }
    return sampleSeries;
}

// Load episodes data
function getEpisodes() {
    const storedEpisodes = localStorage.getItem('yasinAflemy_episodes');
    if (storedEpisodes) {
        return JSON.parse(storedEpisodes);
    }
    return sampleEpisodes;
}

// Save series to localStorage
function saveSeries(series) {
    localStorage.setItem('yasinAflemy_series', JSON.stringify(series));
}

// Save episodes to localStorage
function saveEpisodes(episodes) {
    localStorage.setItem('yasinAflemy_episodes', JSON.stringify(episodes));
}

// Create series card HTML
function createSeriesCard(series) {
    return `
        <div class="series-card" onclick="viewSeries('${series.id}')">
            <img src="${series.poster}" alt="${series.title}" class="series-poster">
            <div class="play-overlay">
                <i class="fas fa-play-circle play-icon"></i>
            </div>
            <div class="series-info">
                <h3 class="series-title">${series.title}</h3>
                <div class="series-meta">
                    <span>${series.year}</span>
                    <span class="series-rating">
                        <i class="fas fa-star"></i> ${series.rating}
                    </span>
                </div>
            </div>
        </div>
    `;
}

// Load home page content
function loadHomePageContent() {
    const series = getSeries();
    
    // New series
    const newSeriesContainer = document.getElementById('new-series');
    if (newSeriesContainer) {
        const newSeries = series.filter(s => s.year === 2024).slice(0, 6);
        newSeriesContainer.innerHTML = newSeries.map(createSeriesCard).join('');
    }
    
    // Most watched
    const mostWatchedContainer = document.getElementById('most-watched');
    if (mostWatchedContainer) {
        const mostWatched = [...series].sort((a, b) => b.views - a.views).slice(0, 6);
        mostWatchedContainer.innerHTML = mostWatched.map(createSeriesCard).join('');
    }
    
    // Recently added
    const recentlyAddedContainer = document.getElementById('recently-added');
    if (recentlyAddedContainer) {
        const recentlyAdded = series.slice(0, 6);
        recentlyAddedContainer.innerHTML = recentlyAdded.map(createSeriesCard).join('');
    }
}

// View series details
function viewSeries(seriesId) {
    window.location.href = `series.html?id=${seriesId}`;
}

// Watch featured series from hero
function watchSeries(seriesId) {
    window.location.href = `series.html?id=${seriesId}`;
}

// Format number (views)
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

// Check if user is admin
function isAdmin() {
    return localStorage.getItem('yasinAflemy_admin') === 'true';
}

// Update admin link visibility
function updateAdminLink() {
    const adminLink = document.getElementById('admin-link');
    if (adminLink) {
        if (isAdmin()) {
            adminLink.href = 'dashboard.html';
        } else {
            adminLink.href = 'admin.html';
        }
    }
}

// Initialize admin link
updateAdminLink();