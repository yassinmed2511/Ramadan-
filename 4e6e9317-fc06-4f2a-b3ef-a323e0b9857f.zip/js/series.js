// Series page JavaScript

let currentSeriesId = null;
let currentEpisodes = [];

// Load series details
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    currentSeriesId = urlParams.get('id');
    
    if (currentSeriesId) {
        loadSeriesDetails(currentSeriesId);
    } else {
        // Redirect to home if no series ID
        window.location.href = 'index.html';
    }
});

function loadSeriesDetails(seriesId) {
    const series = getSeries();
    const seriesData = series.find(s => s.id === seriesId);
    
    if (!seriesData) {
        window.location.href = 'index.html';
        return;
    }
    
    // Update series hero
    const seriesHero = document.getElementById('series-hero');
    if (seriesHero) {
        seriesHero.style.backgroundImage = `url(${seriesData.poster})`;
    }
    
    // Update series poster
    const seriesPoster = document.getElementById('series-poster');
    if (seriesPoster) {
        seriesPoster.src = seriesData.poster;
    }
    
    // Update series info
    document.getElementById('series-title').textContent = seriesData.title;
    document.getElementById('series-description').textContent = seriesData.description;
    document.getElementById('series-year').textContent = seriesData.year;
    document.getElementById('series-category').textContent = seriesData.category;
    document.getElementById('series-rating').innerHTML = `<i class="fas fa-star"></i> ${seriesData.rating}`;
    
    // Load episodes
    loadEpisodes(seriesId);
}

function loadEpisodes(seriesId) {
    const episodes = getEpisodes();
    currentEpisodes = episodes.filter(ep => ep.seriesId === seriesId);
    
    // Sort episodes by number
    currentEpisodes.sort((a, b) => a.episodeNumber - b.episodeNumber);
    
    const episodesGrid = document.getElementById('episodes-grid');
    if (episodesGrid) {
        if (currentEpisodes.length === 0) {
            episodesGrid.innerHTML = `
                <div style="grid-column: 1 / -1; text-align: center; padding: 40px;">
                    <i class="fas fa-video" style="font-size: 60px; color: var(--text-secondary); margin-bottom: 20px;"></i>
                    <p style="color: var(--text-secondary); font-size: 18px;">لا توجد حلقات متاحة حالياً</p>
                </div>
            `;
        } else {
            episodesGrid.innerHTML = currentEpisodes.map(episode => `
                <div class="episode-card" onclick="watchEpisode('${episode.id}')">
                    <div class="episode-number">الحلقة ${episode.episodeNumber}</div>
                    <h3 class="episode-title">${episode.title}</h3>
                    <div class="episode-duration">
                        <i class="fas fa-clock"></i> ${episode.duration} دقيقة
                    </div>
                </div>
            `).join('');
        }
    }
}

function watchEpisode(episodeId) {
    window.location.href = `player.html?seriesId=${currentSeriesId}&episodeId=${episodeId}`;
}

function watchFirstEpisode() {
    if (currentEpisodes.length > 0) {
        watchEpisode(currentEpisodes[0].id);
    }
}