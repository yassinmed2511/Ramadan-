// Admin Dashboard JavaScript

// Admin credentials (in production, use Firebase Authentication)
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'yasin123';

// Check authentication status
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    loadAdminData();
});

function checkAuth() {
    const isDashboard = window.location.pathname.includes('dashboard.html');
    const isLogin = window.location.pathname.includes('admin.html');
    
    if (isDashboard && !isAdmin()) {
        // Redirect to login if not authenticated
        window.location.href = 'admin.html';
    }
    
    if (isLogin && isAdmin()) {
        // Redirect to dashboard if already authenticated
        window.location.href = 'dashboard.html';
    }
}

// Handle login
function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        localStorage.setItem('yasinAflemy_admin', 'true');
        window.location.href = 'dashboard.html';
    } else {
        alert('اسم المستخدم أو كلمة المرور غير صحيحة');
    }
}

// Logout
function logout() {
    localStorage.removeItem('yasinAflemy_admin');
    window.location.href = 'index.html';
}

// Show admin section
function showSection(sectionName) {
    // Hide all sections
    const sections = document.querySelectorAll('.admin-section');
    sections.forEach(section => {
        section.style.display = 'none';
    });
    
    // Show selected section
    const selectedSection = document.getElementById(`${sectionName}-section`);
    if (selectedSection) {
        selectedSection.style.display = 'block';
    }
    
    // Update menu active state
    const menuItems = document.querySelectorAll('.admin-menu-item');
    menuItems.forEach(item => {
        item.classList.remove('active');
    });
    
    event.target.closest('.admin-menu-item').classList.add('active');
    
    // Load section data
    if (sectionName === 'series') {
        loadSeriesList();
    } else if (sectionName === 'episodes') {
        loadEpisodesList();
        loadSeriesOptions();
    } else if (sectionName === 'ads') {
        loadAdsData();
    }
}

// Load admin data
function loadAdminData() {
    if (isAdmin()) {
        loadSeriesList();
    }
}

// ==================== SERIES MANAGEMENT ====================

function showAddSeriesForm() {
    document.getElementById('add-series-form').style.display = 'block';
}

function hideAddSeriesForm() {
    document.getElementById('add-series-form').style.display = 'none';
    document.getElementById('add-series-form').reset();
}

function loadSeriesList() {
    const series = getSeries();
    const seriesList = document.getElementById('series-list');
    
    if (seriesList) {
        seriesList.innerHTML = series.map(s => `
            <tr>
                <td>
                    <img src="${s.poster}" alt="${s.title}" style="width: 50px; height: 75px; object-fit: cover; border-radius: 5px;">
                </td>
                <td>${s.title}</td>
                <td>${s.category}</td>
                <td>${s.year}</td>
                <td><i class="fas fa-star" style="color: var(--primary-gold);"></i> ${s.rating}</td>
                <td>
                    <button class="action-btn edit-btn" onclick="editSeries('${s.id}')">
                        <i class="fas fa-edit"></i> تعديل
                    </button>
                    <button class="action-btn delete-btn" onclick="deleteSeries('${s.id}')">
                        <i class="fas fa-trash"></i> حذف
                    </button>
                </td>
            </tr>
        `).join('');
    }
}

function addSeries(event) {
    event.preventDefault();
    
    const title = document.getElementById('series-title').value;
    const description = document.getElementById('series-description').value;
    const poster = document.getElementById('series-poster').value;
    const category = document.getElementById('series-category').value;
    const year = parseInt(document.getElementById('series-year').value);
    const rating = parseFloat(document.getElementById('series-rating').value);
    
    const series = getSeries();
    const newSeries = {
        id: Date.now().toString(),
        title,
        description,
        poster,
        category,
        year,
        rating,
        views: 0
    };
    
    series.push(newSeries);
    saveSeries(series);
    
    // Reset form and hide
    hideAddSeriesForm();
    
    // Reload list
    loadSeriesList();
    
    alert('تم إضافة المسلسل بنجاح!');
}

function editSeries(seriesId) {
    const series = getSeries();
    const seriesData = series.find(s => s.id === seriesId);
    
    if (!seriesData) return;
    
    // Show form and populate with data
    showAddSeriesForm();
    document.getElementById('series-title').value = seriesData.title;
    document.getElementById('series-description').value = seriesData.description;
    document.getElementById('series-poster').value = seriesData.poster;
    document.getElementById('series-category').value = seriesData.category;
    document.getElementById('series-year').value = seriesData.year;
    document.getElementById('series-rating').value = seriesData.rating;
    
    // Change form submit handler to update instead of add
    const form = document.querySelector('#add-series-form');
    form.onsubmit = function(e) {
        e.preventDefault();
        updateSeries(seriesId);
    };
}

function updateSeries(seriesId) {
    const series = getSeries();
    const seriesIndex = series.findIndex(s => s.id === seriesId);
    
    if (seriesIndex === -1) return;
    
    series[seriesIndex].title = document.getElementById('series-title').value;
    series[seriesIndex].description = document.getElementById('series-description').value;
    series[seriesIndex].poster = document.getElementById('series-poster').value;
    series[seriesIndex].category = document.getElementById('series-category').value;
    series[seriesIndex].year = parseInt(document.getElementById('series-year').value);
    series[seriesIndex].rating = parseFloat(document.getElementById('series-rating').value);
    
    saveSeries(series);
    
    // Reset form
    hideAddSeriesForm();
    
    // Reset form submit handler
    const form = document.querySelector('#add-series-form');
    form.onsubmit = function(e) {
        addSeries(e);
    };
    
    // Reload list
    loadSeriesList();
    
    alert('تم تحديث المسلسل بنجاح!');
}

function deleteSeries(seriesId) {
    if (!confirm('هل أنت متأكد من حذف هذا المسلسل؟ سيتم حذف جميع الحلقات المرتبطة به.')) {
        return;
    }
    
    // Delete series
    let series = getSeries();
    series = series.filter(s => s.id !== seriesId);
    saveSeries(series);
    
    // Delete related episodes
    let episodes = getEpisodes();
    episodes = episodes.filter(ep => ep.seriesId !== seriesId);
    saveEpisodes(episodes);
    
    // Reload list
    loadSeriesList();
    
    alert('تم حذف المسلسل بنجاح!');
}

// ==================== EPISODE MANAGEMENT ====================

function showAddEpisodeForm() {
    document.getElementById('add-episode-form').style.display = 'block';
    loadSeriesOptions();
}

function hideAddEpisodeForm() {
    document.getElementById('add-episode-form').style.display = 'none';
    document.getElementById('add-episode-form').reset();
}

function loadSeriesOptions() {
    const series = getSeries();
    const seriesSelect = document.getElementById('episode-series');
    
    if (seriesSelect) {
        seriesSelect.innerHTML = '<option value="">اختر المسلسل</option>' + 
            series.map(s => `<option value="${s.id}">${s.title}</option>`).join('');
    }
}

function loadEpisodesList() {
    const episodes = getEpisodes();
    const series = getSeries();
    const episodesList = document.getElementById('episodes-list');
    
    if (episodesList) {
        episodesList.innerHTML = episodes.map(ep => {
            const seriesData = series.find(s => s.id === ep.seriesId);
            return `
                <tr>
                    <td>${seriesData ? seriesData.title : 'غير معروف'}</td>
                    <td>${ep.episodeNumber}</td>
                    <td>${ep.title}</td>
                    <td>${ep.duration} دقيقة</td>
                    <td>
                        <button class="action-btn edit-btn" onclick="editEpisode('${ep.id}')">
                            <i class="fas fa-edit"></i> تعديل
                        </button>
                        <button class="action-btn delete-btn" onclick="deleteEpisode('${ep.id}')">
                            <i class="fas fa-trash"></i> حذف
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    }
}

function addEpisode(event) {
    event.preventDefault();
    
    const seriesId = document.getElementById('episode-series').value;
    const episodeNumber = parseInt(document.getElementById('episode-number').value);
    const title = document.getElementById('episode-title').value;
    const videoUrl = document.getElementById('episode-video').value;
    const duration = parseInt(document.getElementById('episode-duration').value);
    
    const episodes = getEpisodes();
    const newEpisode = {
        id: Date.now().toString(),
        seriesId,
        episodeNumber,
        title,
        videoUrl,
        duration
    };
    
    episodes.push(newEpisode);
    saveEpisodes(episodes);
    
    // Reset form and hide
    hideAddEpisodeForm();
    
    // Reload list
    loadEpisodesList();
    
    alert('تم إضافة الحلقة بنجاح!');
}

function editEpisode(episodeId) {
    const episodes = getEpisodes();
    const episodeData = episodes.find(ep => ep.id === episodeId);
    
    if (!episodeData) return;
    
    // Show form and populate with data
    showAddEpisodeForm();
    document.getElementById('episode-series').value = episodeData.seriesId;
    document.getElementById('episode-number').value = episodeData.episodeNumber;
    document.getElementById('episode-title').value = episodeData.title;
    document.getElementById('episode-video').value = episodeData.videoUrl;
    document.getElementById('episode-duration').value = episodeData.duration;
    
    // Change form submit handler to update instead of add
    const form = document.querySelector('#add-episode-form');
    form.onsubmit = function(e) {
        e.preventDefault();
        updateEpisode(episodeId);
    };
}

function updateEpisode(episodeId) {
    const episodes = getEpisodes();
    const episodeIndex = episodes.findIndex(ep => ep.id === episodeId);
    
    if (episodeIndex === -1) return;
    
    episodes[episodeIndex].seriesId = document.getElementById('episode-series').value;
    episodes[episodeIndex].episodeNumber = parseInt(document.getElementById('episode-number').value);
    episodes[episodeIndex].title = document.getElementById('episode-title').value;
    episodes[episodeIndex].videoUrl = document.getElementById('episode-video').value;
    episodes[episodeIndex].duration = parseInt(document.getElementById('episode-duration').value);
    
    saveEpisodes(episodes);
    
    // Reset form
    hideAddEpisodeForm();
    
    // Reset form submit handler
    const form = document.querySelector('#add-episode-form');
    form.onsubmit = function(e) {
        addEpisode(e);
    };
    
    // Reload list
    loadEpisodesList();
    
    alert('تم تحديث الحلقة بنجاح!');
}

function deleteEpisode(episodeId) {
    if (!confirm('هل أنت متأكد من حذف هذه الحلقة؟')) {
        return;
    }
    
    let episodes = getEpisodes();
    episodes = episodes.filter(ep => ep.id !== episodeId);
    saveEpisodes(episodes);
    
    // Reload list
    loadEpisodesList();
    
    alert('تم حذف الحلقة بنجاح!');
}

// ==================== ADS MANAGEMENT ====================

function loadAdsData() {
    const ads = window.ads || loadAds();
    
    // Load ad toggles and codes
    const adTypes = ['header', 'sidebar', 'between-episodes', 'before-episode', 'after-episode', 'footer'];
    
    adTypes.forEach(type => {
        const toggle = document.getElementById(`${type}-ad-toggle`);
        const codeArea = document.getElementById(`${type}-ad-code`);
        
        if (toggle) {
            toggle.checked = ads[type] && ads[type].enabled;
        }
        
        if (codeArea && ads[type] && ads[type].code) {
            codeArea.value = ads[type].code;
        }
    });
}

function toggleAd(adType) {
    if (!window.ads) {
        loadAds();
    }
    
    const toggle = document.getElementById(`${adType}-ad-toggle`);
    if (toggle) {
        window.ads[adType].enabled = toggle.checked;
        localStorage.setItem('yasinAflemy_ads', JSON.stringify(window.ads));
        alert(`تم ${toggle.checked ? 'تفعيل' : 'تعطيل'} إعلان ${adType}`);
    }
}

function saveAd(adType) {
    if (!window.ads) {
        loadAds();
    }
    
    const codeArea = document.getElementById(`${adType}-ad-code`);
    const toggle = document.getElementById(`${adType}-ad-toggle`);
    
    if (codeArea) {
        window.ads[adType].code = codeArea.value;
        window.ads[adType].enabled = toggle ? toggle.checked : false;
        localStorage.setItem('yasinAflemy_ads', JSON.stringify(window.ads));
        alert(`تم حفظ إعلان ${adType} بنجاح!`);
    }
}