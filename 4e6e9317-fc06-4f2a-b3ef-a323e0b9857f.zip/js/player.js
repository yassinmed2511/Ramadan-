// Player page JavaScript

let currentSeriesId = null;
let currentEpisodeId = null;
let currentSeries = null;
let currentEpisode = null;
let seriesEpisodes = [];
let currentEpisodeIndex = 0;

// Load player
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    currentSeriesId = urlParams.get('seriesId');
    currentEpisodeId = urlParams.get('episodeId');
    
    if (currentSeriesId && currentEpisodeId) {
        loadPlayer(currentSeriesId, currentEpisodeId);
    } else {
        window.location.href = 'index.html';
    }
});

function loadPlayer(seriesId, episodeId) {
    // Load series data
    const series = getSeries();
    currentSeries = series.find(s => s.id === seriesId);
    
    if (!currentSeries) {
        window.location.href = 'index.html';
        return;
    }
    
    // Load episode data
    const episodes = getEpisodes();
    seriesEpisodes = episodes.filter(ep => ep.seriesId === seriesId);
    seriesEpisodes.sort((a, b) => a.episodeNumber - b.episodeNumber);
    
    currentEpisode = seriesEpisodes.find(ep => ep.id === episodeId);
    if (!currentEpisode) {
        window.location.href = `series.html?id=${seriesId}`;
        return;
    }
    
    // Get current episode index
    currentEpisodeIndex = seriesEpisodes.findIndex(ep => ep.id === episodeId);
    
    // Update UI
    document.getElementById('episode-title').textContent = currentEpisode.title;
    document.getElementById('series-name').textContent = currentSeries.title;
    
    // Set video source
    const videoPlayer = document.getElementById('video-player');
    if (videoPlayer && currentEpisode.videoUrl) {
        videoPlayer.src = currentEpisode.videoUrl;
        videoPlayer.load();
    }
    
    // Update navigation buttons
    updateNavigationButtons();
    
    // Load related episodes
    loadRelatedEpisodes();
}

function updateNavigationButtons() {
    const prevBtn = document.getElementById('prev-episode-btn');
    const nextBtn = document.getElementById('next-episode-btn');
    
    // Previous button
    if (prevBtn) {
        if (currentEpisodeIndex > 0) {
            prevBtn.disabled = false;
            prevBtn.style.opacity = '1';
        } else {
            prevBtn.disabled = true;
            prevBtn.style.opacity = '0.5';
        }
    }
    
    // Next button
    if (nextBtn) {
        if (currentEpisodeIndex < seriesEpisodes.length - 1) {
            nextBtn.disabled = false;
            nextBtn.style.opacity = '1';
        } else {
            nextBtn.disabled = true;
            nextBtn.style.opacity = '0.5';
        }
    }
}

function playPreviousEpisode() {
    if (currentEpisodeIndex > 0) {
        const prevEpisode = seriesEpisodes[currentEpisodeIndex - 1];
        window.location.href = `player.html?seriesId=${currentSeriesId}&episodeId=${prevEpisode.id}`;
    }
}

function playNextEpisode() {
    if (currentEpisodeIndex < seriesEpisodes.length - 1) {
        const nextEpisode = seriesEpisodes[currentEpisodeIndex + 1];
        window.location.href = `player.html?seriesId=${currentSeriesId}&episodeId=${nextEpisode.id}`;
    }
}

function goToSeries() {
    window.location.href = `series.html?id=${currentSeriesId}`;
}

function loadRelatedEpisodes() {
    const relatedEpisodesContainer = document.getElementById('related-episodes');
    if (relatedEpisodesContainer) {
        relatedEpisodesContainer.innerHTML = seriesEpisodes.map((episode, index) => `
            <div class="episode-card ${index === currentEpisodeIndex ? 'active' : ''}" 
                 onclick="playEpisode('${episode.id}')"
                 style="${index === currentEpisodeIndex ? 'border-color: var(--primary-gold); background: var(--dark-hover);' : ''}">
                <div class="episode-number">الحلقة ${episode.episodeNumber}</div>
                <h3 class="episode-title">${episode.title}</h3>
                <div class="episode-duration">
                    <i class="fas fa-clock"></i> ${episode.duration} دقيقة
                </div>
                ${index === currentEpisodeIndex ? '<i class="fas fa-play" style="color: var(--primary-gold); position: absolute; top: 10px; left: 10px;"></i>' : ''}
            </div>
        `).join('');
    }
}

function playEpisode(episodeId) {
    window.location.href = `player.html?seriesId=${currentSeriesId}&episodeId=${episodeId}`;
}

// Auto-play next episode when video ends
document.addEventListener('DOMContentLoaded', function() {
    const videoPlayer = document.getElementById('video-player');
    if (videoPlayer) {
        videoPlayer.addEventListener('ended', function() {
            // Auto-play next episode after 3 seconds
            setTimeout(function() {
                if (currentEpisodeIndex < seriesEpisodes.length - 1) {
                    playNextEpisode();
                }
            }, 3000);
        });
    }
});