// Categories page JavaScript

let currentCategory = 'all';

// Initialize categories page
document.addEventListener('DOMContentLoaded', function() {
    loadCategorySeries('all');
});

function filterByCategory(category) {
    currentCategory = category;
    
    // Update active button
    const buttons = document.querySelectorAll('.category-btn');
    buttons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.textContent.includes(getCategoryName(category)) || (category === 'all' && btn.textContent.includes('الكل'))) {
            btn.classList.add('active');
        }
    });
    
    // Load series for category
    loadCategorySeries(category);
}

function getCategoryName(category) {
    const categoryNames = {
        'all': 'الكل',
        'دراما': 'دراما',
        'كوميديا': 'كوميديا',
        'تاريخي': 'تاريخي',
        'رومانسي': 'رومانسي',
        'غموض': 'غموض',
        'عائلي': 'عائلي',
        'اجتماعي': 'اجتماعي'
    };
    return categoryNames[category] || category;
}

function loadCategorySeries(category) {
    const series = getSeries();
    let filteredSeries = series;
    
    if (category !== 'all') {
        filteredSeries = series.filter(s => s.category === category);
    }
    
    const categoryResultsContainer = document.getElementById('category-results');
    const noResults = document.getElementById('no-category-results');
    
    if (filteredSeries.length > 0) {
        categoryResultsContainer.innerHTML = filteredSeries.map(createSeriesCard).join('');
        noResults.style.display = 'none';
    } else {
        categoryResultsContainer.innerHTML = '';
        noResults.style.display = 'block';
    }
}