// Search page JavaScript

let searchTimeout = null;

// Initialize search page
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        // Focus on search input
        searchInput.focus();
        
        // Perform search if there's a query in URL
        const urlParams = new URLSearchParams(window.location.search);
        const query = urlParams.get('q');
        if (query) {
            searchInput.value = query;
            performSearch(query);
        }
    }
});

function performSearch(query = null) {
    if (!query) {
        query = document.getElementById('search-input').value.trim();
    }
    
    // Clear previous timeout
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    }
    
    // Debounce search (wait 300ms after typing stops)
    searchTimeout = setTimeout(function() {
        executeSearch(query);
    }, 300);
}

function executeSearch(query) {
    const searchResultsContainer = document.getElementById('search-results');
    const searchResultsInfo = document.getElementById('search-results-info');
    const noResults = document.getElementById('no-results');
    
    if (!query) {
        searchResultsContainer.innerHTML = '';
        searchResultsInfo.textContent = '';
        noResults.style.display = 'block';
        return;
    }
    
    // Get all series
    const series = getSeries();
    
    // Filter series by title or description
    const filteredSeries = series.filter(s => {
        const titleMatch = s.title.toLowerCase().includes(query.toLowerCase());
        const descMatch = s.description.toLowerCase().includes(query.toLowerCase());
        const categoryMatch = s.category.toLowerCase().includes(query.toLowerCase());
        return titleMatch || descMatch || categoryMatch;
    });
    
    // Display results
    if (filteredSeries.length > 0) {
        searchResultsInfo.textContent = `تم العثور على ${filteredSeries.length} نتيجة لـ "${query}"`;
        searchResultsContainer.innerHTML = filteredSeries.map(createSeriesCard).join('');
        noResults.style.display = 'none';
    } else {
        searchResultsInfo.textContent = '';
        searchResultsContainer.innerHTML = '';
        noResults.style.display = 'block';
    }
}

// Handle Enter key in search input
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                executeSearch(searchInput.value);
            }
        });
    }
});